import { createBrowserRouter } from "react-router";
import { PortfolioHome } from "./components/PortfolioHome";
import { AboutPage } from "./components/AboutPage";
import { DesignSystemPage } from "./components/DesignSystemPage";
import { NotFound } from "./components/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: PortfolioHome,
  },
  {
    path: "/about",
    Component: AboutPage,
  },
  {
    path: "/design-system",
    Component: DesignSystemPage,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);